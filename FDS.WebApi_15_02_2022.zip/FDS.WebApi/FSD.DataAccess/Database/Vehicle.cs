﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FSD.DataAccess.Database
{
    [Table("Vehicle")]
    public partial class Vehicle
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }
        public string LicensePlate { get; set; }
        public string ChassisNo { get; set; }
        public DateTime RegDate { get; set; }
    }
}
