﻿using FDS.BusinessLogic.Interface;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace FDS.WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class VehicleController : ControllerBase
    {
        private readonly IVehicleManager _vehicleManager;

        public VehicleController(IVehicleManager vehicleManager)
        {
            _vehicleManager = vehicleManager;
        }

        [CustomApiSecurity]
        [HttpGet]
        [Route("Vehicles")]
        public IActionResult GetVehicles()
        {
            var vehicles = _vehicleManager.GetVehicles();
            return Ok(vehicles);
        }
    }
}
