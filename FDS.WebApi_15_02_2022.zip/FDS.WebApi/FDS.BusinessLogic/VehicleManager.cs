﻿using FDS.BusinessEntities;
using FDS.BusinessLogic.Interface;
using FSD.DataAccess.Database;
using FSD.DataAccess.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FDS.BusinessLogic
{
    public class VehicleManager : IVehicleManager
    {
        private readonly IVehicleRepository _vehicleRepository;

        public VehicleManager(IVehicleRepository vehicleRepository)
        {
            _vehicleRepository = vehicleRepository;
        }

        public IList<VehicleViewModel> GetVehicles()
        {
            IList<VehicleViewModel> vehicles = new List<VehicleViewModel>();

            var vehicleList = _vehicleRepository.GetVehicles();
            if (vehicleList.Any())
            {
                foreach (var vehicle in vehicleList)
                {
                    var vehicleViewModel = new VehicleViewModel
                    {
                        Id = vehicle.Id,
                        LicensePlate = vehicle.LicensePlate,
                        ChassisNo = vehicle.ChassisNo,
                        RegDate = vehicle.RegDate                        
                    };
                    vehicles.Add(vehicleViewModel);
                }
            }

            return vehicles;
        }
    }
}
