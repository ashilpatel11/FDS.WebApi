﻿using FDS.BusinessEntities;
using FDS.BusinessLogic.Interface;
using FSD.DataAccess.Interface;

namespace FDS.BusinessLogic
{
    public class CustomerManager : ICustomerManager
    {
        private readonly ICustomerRepository _customerRepository;

        public CustomerManager(ICustomerRepository customerRepository)
        {
            _customerRepository = customerRepository;
        }

        public IList<CustomerViewModel> GetCustomers()
        {
            IList<CustomerViewModel> customerViewModels = new List<CustomerViewModel>();

            var customers = _customerRepository.GetCustomers();
            if (customers.Any())
            {
                foreach (var customer in customers)
                {
                    var customerViewModel = new CustomerViewModel
                    {
                        Id = customer.Id,
                        Name = customer.Name,
                        Address = customer.Address,
                        Email = customer.Email,
                        MobileNo = customer.MobileNo,
                        CustomerType = customer.Id > 3 ? "Owner" : "Employee"
                    };
                    customerViewModels.Add(customerViewModel);
                }
            }

            return customerViewModels;
        }

        public CustomerViewModel GetCustomerById(int id)
        {
            CustomerViewModel customerViewModel = new CustomerViewModel();

            var customer = _customerRepository.GetCustomerById(id);
            if (customer != null)
            {
                customerViewModel = new CustomerViewModel
                {
                    Id = customer.Id,
                    Name = customer.Name,
                    Address = customer.Address,
                    Email = customer.Email,
                    MobileNo = customer.MobileNo,
                    CustomerType = customer.Id > 3 ? "Owner" : "Employee"
                };
            }

            return customerViewModel;
        }
    }
}
