﻿
using FDS.BusinessEntities;

namespace FDS.BusinessLogic.Interface
{
    public interface ICustomerManager
    {
        IList<CustomerViewModel> GetCustomers();
        CustomerViewModel GetCustomerById(int id);
    }
}
