﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FDS.BusinessEntities
{
    public class VehicleViewModel
    {
        public int Id { get; set; }
        public string LicensePlate { get; set; }
        public string ChassisNo { get; set; }
        public DateTime RegDate { get; set; }
    }
}
