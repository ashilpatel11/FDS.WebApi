﻿
namespace FDS.BusinessEntities
{
    public class CustomerViewModel
    {
        public CustomerViewModel()
        {
            Vehicles = new List<VehicleViewModel>();
        }

        public int Id { get; set; }
        public string Name { get; set; }
        public string Address { get; set; }
        public string Email { get; set; }
        public string MobileNo { get; set; }
        public string CustomerType { get; set; }
        public IList<VehicleViewModel> Vehicles { get; set; }
    }
}
