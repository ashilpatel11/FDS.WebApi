﻿using Microsoft.EntityFrameworkCore;

namespace FSD.DataAccess.Database
{
    public class FDSContext : DbContext
    {
        public FDSContext(DbContextOptions options)
            : base(options)
        {

        }

        public DbSet<Customer> Customers { get; set; }
        public DbSet<Vehicle> Vehicles { get; set; }
    }
}
