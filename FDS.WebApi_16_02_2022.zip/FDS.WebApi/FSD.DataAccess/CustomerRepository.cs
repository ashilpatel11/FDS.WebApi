﻿
using FSD.DataAccess.Database;
using FSD.DataAccess.Interface;

namespace FSD.DataAccess
{
    public class CustomerRepository : ICustomerRepository
    {
        private FDSContext _dbContext;

        public CustomerRepository(FDSContext dbContext)
        {
            _dbContext = dbContext;
        }

        public IList<Customer> GetCustomers()
        {
            var customers = _dbContext.Customers.ToList();
            return customers;
        }

        public Customer GetCustomerById(int id)
        {
            var customer = GetCustomers().FirstOrDefault(x => x.Id == id);
            if (customer != null)
            {
                return customer;
            }
            return new Customer();
        }
    }
}