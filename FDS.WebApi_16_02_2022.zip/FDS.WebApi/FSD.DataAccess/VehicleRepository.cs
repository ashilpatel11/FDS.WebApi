﻿using FSD.DataAccess.Database;
using FSD.DataAccess.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FSD.DataAccess
{
    public class VehicleRepository: IVehicleRepository
    {
        private FDSContext _dbContext;

        public VehicleRepository(FDSContext dbContext)
        {
            _dbContext = dbContext;
        }

        public IList<Vehicle> GetVehicles()
        {
            return _dbContext.Vehicles.ToList();
        }
    }
}
