﻿using FSD.DataAccess.Database;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FSD.DataAccess.Interface
{
    public interface IVehicleRepository
    {
        IList<Vehicle> GetVehicles();
    }
}
