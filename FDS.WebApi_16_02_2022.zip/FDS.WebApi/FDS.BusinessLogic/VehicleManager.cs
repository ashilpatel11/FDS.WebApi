﻿using FDS.BusinessEntities;
using FDS.BusinessLogic.Interface;
using FDS.Common;
using FSD.DataAccess.Database;
using FSD.DataAccess.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FDS.BusinessLogic
{
    public class VehicleManager : IVehicleManager
    {
        private readonly IVehicleRepository _vehicleRepository;

        public VehicleManager(IVehicleRepository vehicleRepository)
        {
            _vehicleRepository = vehicleRepository;
        }

        public IList<VehicleViewModel> GetVehicles()
        {
            IList<VehicleViewModel> vehicles = new List<VehicleViewModel>();

            var vehicleList = _vehicleRepository.GetVehicles();
            if (vehicleList.Any())
            {
                vehicles = vehicleList.JsonCast<IList<VehicleViewModel>>();
            }

            return vehicles;
        }
    }
}
