﻿using Microsoft.AspNetCore.Authorization;
using System.Web.Http.Controllers;

namespace FDS.WebApi
{
    public sealed class CustomApiSecurity : AuthorizeAttribute
    {
        ///// <summary>
        ///// Occurs before the action method is invoked.
        ///// </summary>
        ///// <param name="actionContext">The action context.</param>
        //public override void OnAuthorization(HttpActionContext actionContext)
        //{
        //    if (Authorize(actionContext))
        //    {
        //        return;
        //    }

        //    //Handle Unauthorized Request
        //    HandleUnauthorizedRequest(actionContext);
        //}

        ///// <summary>
        ///// Handles the unauthorized request.
        ///// </summary>
        ///// <param name="filterContext">The filter context.</param>
        //protected override void HandleUnauthorizedRequest(HttpActionContext filterContext)
        //{
        //    if (filterContext == null)
        //    {
        //        return;
        //    }

        //    filterContext.Response = filterContext.Request.CreateResponse(HttpStatusCode.Unauthorized, new { Message = CommonConstant.AuthorizationMessage }, filterContext.ControllerContext.Configuration.Formatters.JsonFormatter);
        //    base.HandleUnauthorizedRequest(filterContext);
        //}

        ///// <summary>
        ///// Authorizes the specified action context.
        ///// </summary>
        ///// <param name="actionContext">The action context.</param>
        ///// <returns></returns>
        //private static bool Authorize(HttpActionContext actionContext)
        //{
        //    try
        //    {
        //        var request = actionContext.Request.Headers.Authorization;
        //        if (!string.IsNullOrEmpty(request?.Scheme))
        //        {
        //            return request.Scheme == SiteSettings.ApiSecurityToken;
        //        }
        //        return false;
        //    }
        //    catch (NullReferenceException)
        //    {
        //        return true;
        //    }
        //    catch (InvalidOperationException)
        //    {
        //        return true;
        //    }
        //    catch (Exception)
        //    {
        //        return true;
        //    }
        //}
    }
}
