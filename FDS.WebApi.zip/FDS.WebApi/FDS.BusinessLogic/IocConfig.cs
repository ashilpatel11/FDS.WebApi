﻿using FDS.BusinessLogic.Interface;
using Microsoft.Extensions.DependencyInjection;

namespace FDS.BusinessLogic
{
    public static class IocConfig
    {
        public static void ConfigureServices(ref IServiceCollection services)
        {
            services.AddTransient<ICustomerManager, CustomerManager>();

            //Resolve Depedency for the Repository
            FSD.DataAccess.IocConfig.ConfigureServices(ref services);
        }
    }
}
