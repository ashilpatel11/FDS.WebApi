﻿
using FSD.DataAccess.Database;
using FSD.DataAccess.Interface;

namespace FSD.DataAccess
{
    public class CustomerRepository : ICustomerRepository
    {
        public IList<Customer> GetCustomers()
        {
            IList<Customer> customers = new List<Customer>
            {
                new Customer{ Id = 1, Name = "Test Custome 1",Address = "Test Address 1", Email = "test@gmail.com",MobileNo = "989898989" },
                new Customer{ Id = 2, Name = "Test Custome 2",Address = "Test Address 2", Email = "test1@gmail.com",MobileNo = "888888888" },
                new Customer{ Id = 3, Name = "Test Custome 3",Address = "Test Address 3", Email = "test2@gmail.com",MobileNo = "777777777" },
                new Customer{ Id = 4, Name = "Test Custome 4",Address = "Test Address 4", Email = "test3@gmail.com",MobileNo = "454555555" },
                new Customer{ Id = 5, Name = "Test Custome 5",Address = "Test Address 5", Email = "test4@gmail.com",MobileNo = "774747477" },
            };
            return customers;
        }

        public Customer GetCustomerById(int id)
        {
            var customer = GetCustomers().FirstOrDefault(x => x.Id == id);
            if (customer != null)
            {
                return customer;
            }
            return new Customer();
        }
    }
}