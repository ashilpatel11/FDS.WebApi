﻿using FSD.DataAccess.Interface;
using Microsoft.Extensions.DependencyInjection;

namespace FSD.DataAccess
{
    public static class IocConfig
    {
        public static void ConfigureServices(ref IServiceCollection services)
        {
            services.AddTransient<ICustomerRepository, CustomerRepository>();
        }
    }
}
