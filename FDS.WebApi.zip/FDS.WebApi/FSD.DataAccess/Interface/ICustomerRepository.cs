﻿
using FSD.DataAccess.Database;

namespace FSD.DataAccess.Interface
{
    public interface ICustomerRepository
    {
        IList<Customer> GetCustomers();
        Customer GetCustomerById(int id);
    }
}
